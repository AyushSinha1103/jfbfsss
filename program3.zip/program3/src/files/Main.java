package files;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.*;
import org.hibernate.*;
import java.util.*;



public class Main {
	SessionFactory sc = new Configuration().configure("hibernate-conf.xml").buildSessionFactory();
	
	public void insert(int id, String usn,String name) {
		Session session = sc.openSession();
		Transaction t = session.beginTransaction();
		student e1=new student();
		e1.setId(id);
		e1.setUsn(usn);
		e1.setName(name);
		session.save(e1);
		t.commit();
		System.out.print("Entered Succesfully");
		}

	public void update(int id,String name) {
	
		Session session = sc.openSession();
		Transaction t = session.beginTransaction();
	    Query query = session.createQuery("update student set name = '"+name+"' where id ='"+id+"'");
	    query.executeUpdate();
	    System.out.print("updated Succesfully");
		t.commit();
	}
	
	public void delete(int id) {
		Session session = sc.openSession();
		Transaction t = session.beginTransaction();
		student e=new student();
		e.setId(id);
		session.delete(e);
		t.commit();
		System.out.println("Deleted");
	}
	
	
	public void display() {
		Session session = sc.openSession();
		Transaction t = session.beginTransaction();
		Query q = session.createQuery("from student");
		List<?> l = q.getResultList();
		Iterator<?> it = l.iterator();
		if(!it.hasNext()) {
			System.out.println("\n\nNo Employees!!!\n");

		}
		while (it.hasNext()) {
			student e1 = (student) it.next();
			System.out.println("\nEmp ID :"+e1.getId()+
					"\t\tUsn :"+e1.getUsn()+
					"\t\tName :"+e1.getName());
		}
		t.commit();
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main m1= new Main();
		Scanner sc=new Scanner(System.in);
		int id, ch=0;
		String name,usn;
		while(true) {
		System.out.println("\n\n1.Insert\t2.Update\n3.Delete\t4.Display\nPress 0 to exit\n");
		ch=sc.nextInt();		
			if(ch==1) {
				System.out.println("ID :");
				id=sc.nextInt();
				System.out.println("USN :");
				usn=sc.next();
				System.out.println("Name :");
				name=sc.next();
				m1.insert(id, usn, name);
			}
			else if(ch==2) {
				System.out.println("ID :");
				id=sc.nextInt();
				System.out.println("Name :");
				name=sc.next();
				m1.update(id, name);
			}
			else if(ch==3) {
				System.out.println("ID :");
				id=sc.nextInt();
				m1.delete(id);
			}
			else if(ch==4) {
				m1.display();
			}
			else {
				break;
			}
		}
	}


}
