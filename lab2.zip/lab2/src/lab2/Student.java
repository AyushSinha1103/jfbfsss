package lab2;

import java.util.*;

public class Student implements Comparable<Student>{
	String usn, name, age;
	
	public Student(String usn, String name, String age) {
		this.usn = usn;
		this.name = name;
		this.age = age;
	}
	
	public int compareTo(Student person) {
		return name.compareTo(person.name);  
	}
	
	public void display(List<Student> list) {
		Iterator<Student> itr = list.iterator();
		while(itr.hasNext()) {
			Student obj = itr.next();
			System.out.println("usn: " +obj.usn+ " Name: "+obj.name+ " Age: "+obj.age);
		}
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Student e = null;
		ArrayList<Student> list1 = new ArrayList<Student>();
		while(true) {
			System.out.println("1 : insert 2 : update  3 : remove 4 : display  5 : size 6 : sort by name 7 : clear");
			int n = sc.nextInt();
			if(n == 1) {
				System.out.println("Enter usn :");
				String usn = sc.next();
				System.out.println("Enter name :");
				String name = sc.next();
				System.out.println("Enter age :");
				String age = sc.next();
				e = new Student(usn, name, age);
				list1.add(e);
			}
			else if(n == 2) {
				System.out.println("Enter index of element to be updated");
				int index  = sc.nextInt();
				System.out.println("Enter usn :");
				String usn = sc.next();
				System.out.println("Enter name :");
				String name = sc.next();
				System.out.println("Enter age :");
				String age = sc.next();
				e = new Student(usn, name, age);
				list1.set(index,e);
			}
			else if(n == 3) {
				System.out.println("Enter index of element to be removed");
				int index  = sc.nextInt();
				list1.remove(index);
			}
			else if(n == 4) {
				e.display(list1);
			}
			else if(n == 5) {
				System.out.println("Size: "+list1.size());
			}
			else if(n == 6) {
				Collections.sort(list1);
				e.display(list1);
			}
			else if(n == 7) {
				list1.clear();
			}		
			else
				break;
		}


	}
	

}