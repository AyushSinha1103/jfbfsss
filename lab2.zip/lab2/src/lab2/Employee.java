package lab2;

import java.util.*;

public class Employee implements Comparable<Employee>{
	String empid, name, age;
	
	public Employee(String empid, String name, String age) {
		this.empid = empid;
		this.name = name;
		this.age = age;
	}
	
	public int compareTo(Employee person) {
		return name.compareTo(person.name);  
	}
	
	public void display(List<Employee> list) {
		Iterator<Employee> itr = list.iterator();
		while(itr.hasNext()) {
			Employee obj = itr.next();
			System.out.println("EMPID: " +obj.empid+ " Name: "+obj.name+ " Age: "+obj.age);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Employee e = null;
		LinkedList<Employee> list1 = new LinkedList<Employee>();
		while(true) {
			System.out.println("1 : insert 2 : update  3 : remove 4 : display  5 : size  6 : clear  7: add first 8 : addLast 9: remove first 10: remove last 11 : sort by name");
			int n = sc.nextInt();
			if(n == 1) {
				System.out.println("Enter empid :");
				String empid = sc.next();
				System.out.println("Enter name :");
				String name = sc.next();
				System.out.println("Enter age :");
				String age = sc.next();
				e = new Employee(empid, name, age);
				list1.add(e);
			}
			else if(n == 2) {
				System.out.println("Enter index of element to be updated");
				int index  = sc.nextInt();
				System.out.println("Enter empid :");
				String empid = sc.next();
				System.out.println("Enter name :");
				String name = sc.next();
				System.out.println("Enter age :");
				String age = sc.next();
				e = new Employee(empid, name, age);
				list1.set(index,e);
			}
			else if(n == 3) {
				System.out.println("Enter index of element to be removed");
				int index  = sc.nextInt();
				list1.remove(index);
			}
			else if(n == 4) {
				e.display(list1);
			}
			else if(n == 5) {
				System.out.println("Size: "+list1.size());
			}
			else if(n == 6) {
				list1.clear();
			}
				
			else if(n == 7) {
				System.out.println("Enter empid :");
				String empid = sc.next();
				System.out.println("Enter name :");
				String name = sc.next();
				System.out.println("Enter age :");
				String age = sc.next();
				e = new Employee(empid, name, age);
				list1.addFirst(e);
			}
			else if(n == 8) {
				System.out.println("Enter empid :");
				String empid = sc.next();
				System.out.println("Enter name :");
				String name = sc.next();
				System.out.println("Enter age :");
				String age = sc.next();
				e = new Employee(empid, name, age);
				list1.addLast(e); 
			}
			else if(n == 9) {
				list1.removeFirst();
			}
			else if(n == 10) {
				list1.removeLast();
			}
			else if(n == 11) {
				Collections.sort(list1);
				e.display(list1);
			}
				
			else
				break;
		}


	}
	

}