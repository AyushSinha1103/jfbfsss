package program5;


public class college {
	private String clgName, course;

	public String getClgName() {
		return clgName;
	}

	public void setClgName(String clgName) {
		this.clgName = clgName;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "college [clgName=" + clgName + ", course=" + course + "]";
	}
	
}
