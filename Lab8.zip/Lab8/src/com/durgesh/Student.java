package com.durgesh;

public class Student {

}
