package files;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class RestMessageController {
	ArrayList<Message> al = new ArrayList<Message>();
	@RequestMapping("/")
	public Message getMessageById() {
		Message m1 = null;
		return m1;
	}
	
	@RequestMapping(value = "/add")
	public List<Message> add(@RequestParam int id, String message){
		Message m1 = new Message(id,message);
			al.add(m1);
			return al;
	}
	@RequestMapping(value = "/delete/{id}")
	public List<Message> delete(@PathVariable int id) {
		lp : for(Message m : al) {
			if(m.getId() == id) {
				al.remove(m);
				break lp;
			}
		}
		return al;
	}
	@RequestMapping(value = "/delete")
	public List<Message> deleteAll() {
		al.clear();
		return al;
	}
	@RequestMapping(value = "/display")
	public List<Message> displayAll(){
		return al;
	}
	@RequestMapping(value = "/display/{id}")
	public Message getMessageById(@PathVariable int id) {
		Message m1 = null;
		lp : for(Message m : al) {
			if(m.getId() == id) {
				m1 = m;
				break lp;
			}
		}
		return m1;
	}
	
	@RequestMapping(value = "/update")
	public List<Message> update(@RequestParam int id, String message) {
		int index = 0;
		Message m1 = null;
		lp : for(Message m : al) {
			if(m.getId() == id) {
				m.setMessage(message);
				m1 = m;
				break lp;
			}
			index++;
		}
		al.set(index, m1);
		return al;
	}
	

}
