package lab1;

import java.util.*;

public class hashMap {
	public void display(Map<String, String> map) {
		System.out.println("============Using EntrySet==============");
		System.out.println(map.entrySet());
		System.out.println("============Using Iterator==============");
		Iterator <String> it = map.keySet().iterator();
		while(it.hasNext()) {
			String key = it.next();
			System.out.println("State: "+key+"\tCapital: "+map.get(key));
		}
	}
	public static void main(String[] args) {
		
		hashMap obj = new hashMap();
		String state,capital;
		Scanner sc = new Scanner(System.in);
		Map<String,String> cmap= new HashMap<>();
		while(true) {
			System.out.println("1.insert 2.Display 3. display only keys 4. display only values 5.Search 6.Remove 7.Update 8.Sort 9.Size 10.Clear");
			int ch=sc.nextInt();
			if(ch==1) {
				System.out.println("Enter State");
				state=sc.next();
				System.out.println("Enter Capital");
				capital = sc.next();
				cmap.put(state, capital);
			}
			else if(ch==2) {
				obj.display(cmap);
			}
			else if(ch == 3) {
				System.out.println("keys: " + cmap.keySet()); 
			}
			else if(ch == 4) {
				System.out.println("Values: " + cmap.values()); 
			}
			else if(ch==5) {
				System.out.println("Enter State name to be searched :");
				state = sc.next();
				if(cmap.containsKey(state)) {
					System.out.println("State : "+state+"\tCapital : "+cmap.get(state));
				}
				else {
					System.out.println("State not present");
				}
			}
			else if(ch==6) {
				System.out.println("Enter State name to be removed :");
				state = sc.next();
				if(cmap.containsKey(state)) {
					cmap.remove(state);
					System.out.println(state + " removed");
				}
				else {
					System.out.println("State not present");
				}
				
			}
			else if(ch==7) {
				System.out.println("Enter State whose Capital to be updated :");
				state = sc.next();
				if(cmap.containsKey(state)) {
					System.out.println("Enter the Capital name :");
					capital = sc.next();
					cmap.replace(state, capital);
					System.out.println("Sucessfully updated");
				}
				else {
					System.out.println("State not present");
				}
				
			}
			else if(ch == 8) {
				TreeMap<String, String> sorted = new TreeMap<>();
				sorted.putAll(cmap);
				obj.display(sorted);
				
			}
			else if(ch==9) {
				System.out.println(cmap.size());
			}
			else if(ch==10) {
				cmap.clear();
				System.out.println("Hash Map is cleared");
			}
		}
	}

}