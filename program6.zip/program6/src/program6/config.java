package program6;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import program6.college;
import program6.student;

@Configuration
public class config{
	@Bean
	@Scope(value=ConfigurableBeanFactory.SCOPE_SINGLETON)
	public student get_Stud_Bean() {
		return new student();
	}
	@Bean
	@Scope(value=ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public college get_College_Bean() {
		return new college();
	}
}