package program6;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context1 = new AnnotationConfigApplicationContext(config.class);
		student st = (student)context1.getBean(student.class);
		college cl = (college)context1.getBean(college.class);
		Scanner sc = new Scanner(System.in);
		String name, clgname, course;
		int age;
		System.out.println("Welcome Student");
		while(true) {
			System.out.println("Enter name: ");
			name = sc.next();
			System.out.println("Enter college name: ");
			clgname = sc.next();
			System.out.println("Enter course: ");
			course = sc.next();
			System.out.println("Enter age: ");
			age = sc.nextInt();
			st.setName(name);
			st.setAge(age);
			cl.setClgName(clgname);
			cl.setCourse(course);
			st.setClg(cl);
			System.out.println(st);
			System.out.println("Press 1 to continue: ");
			int n = sc.nextInt();
			if(n == 1)
				continue;
			else
				break;
		}
		

	}

}
